package com.zhlhlf.test;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component //必须添加  否则编译报错
@ConfigurationProperties(prefix = "aaaa") //这个绑定值
class test{

     String id;
     String name;

    public void setId(String id) {this.id = id;}
    public void setName(String name) {this.name = name;}

    //上面两个设置函数必须有 不然也无法绑定参数

    public String toString(){
        return "id: "+id+"\n"+"name: "+name+"  ";
    }
}