package com.zhlhlf.test;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.zhlhlf.test.test;

import jakarta.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class aaa {
    @Autowired
    private Environment env;

    @Autowired  //自动导入
    test d;
    
    @RequestMapping(value = {"/a"})
    String a(){
        return d.toString();
    }

    @RequestMapping(value = {"/b"})
    String b(@RequestParam("id") String aa){
        return aa;
    }

    @GetMapping("/c/{id}")
    String c(@PathVariable("id") String aa){
        return aa;
    }

    @PostMapping("/add")
    String d(@RequestBody test a){ //Post请求映射数据到对象a
        System.out.println(a);
/*         System.out.println(h); */
        return a.toString();
    }

}


@Controller
class ff{

}

